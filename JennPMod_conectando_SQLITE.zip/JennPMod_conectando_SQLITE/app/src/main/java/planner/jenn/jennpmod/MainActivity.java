package planner.jenn.jennpmod;
//ESTUDIANTE: Jennifer Vanessa Organista Paz
//ID: 785957


import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 🔹 Asegurar que la base de datos se abre
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase(); // Abre la BD para lectura

        Button horarioButton = findViewById(R.id.horarioButton);
        Button recordatoriosButton = findViewById(R.id.recordatoriosButton);
        Button notasButton = findViewById(R.id.notasButton);
        Button climaButton = findViewById(R.id.climaButton);
        Button profileButton = findViewById(R.id.profileButton);

        horarioButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HorarioActivity.class);
            startActivity(intent);
        });

        recordatoriosButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RecordatoriosActivity.class);
            startActivity(intent);
        });

        notasButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, NotasActivity.class);
            startActivity(intent);
        });

        climaButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ClimaActivity.class);
            startActivity(intent);
        });

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
            startActivity(intent);
        });
    }
}

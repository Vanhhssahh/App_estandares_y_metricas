package planner.jenn.jennpmod;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class RegisterActivity extends AppCompatActivity {

        private EditText etNombre, etCorreo, etContrasena, etConfirmarContrasena;
        private Button btnRegistrar;
        private DatabaseHelper dbHelper;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_register);



            Button registerButton = findViewById(R.id.btnCrearCuenta);

            registerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Navegar a Login después del registro
                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
            });

            dbHelper = new DatabaseHelper(this);

            etNombre = findViewById(R.id.etNombreUsuarioRegister);
            etCorreo = findViewById(R.id.etCorreoUsuarioRegister);
            etContrasena = findViewById(R.id.etContrasenaUsuarioRegister);
            etConfirmarContrasena = findViewById(R.id.etConfirmarContrasenaUsuarioRegister);
            btnRegistrar = findViewById(R.id.btnCrearCuenta);

            btnRegistrar.setOnClickListener(view -> {
                String nombre = etNombre.getText().toString().trim();
                String correo = etCorreo.getText().toString().trim();
                String password = etContrasena.getText().toString().trim();
                String confirmarPassword = etConfirmarContrasena.getText().toString().trim();

                if (nombre.isEmpty() || correo.isEmpty() || password.isEmpty() || confirmarPassword.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!password.equals(confirmarPassword)) {
                    Toast.makeText(RegisterActivity.this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (dbHelper.registrarUsuario(nombre, correo, password)) {
                    Toast.makeText(RegisterActivity.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                    finish();
                } else {
                    Toast.makeText(RegisterActivity.this, "Error al registrar", Toast.LENGTH_SHORT).show();
                }


            });
        }
}
